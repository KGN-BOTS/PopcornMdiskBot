START_MESSAGE = "**Hi {}\n\nI'm a bot that search for movies in the Url format. Simply send me the title of a film and I'll send it to you if it's in my database.**"

NO_RESULTS_FOUND = '''**No Results Found for {}❗️ \n\n 1.please Write Correct spelling From Google \n\n 2.Do Not add Season or Episode \n\n 3.Do Not add languages or Year \n\n 4.Write only correct movie/Series Name \n\n 5.if Movie Not found Then Request to Admin

Type Only Movie Name 💬
Check Spelling On [Google]({}) 🔍**'''

BATCH = """**This command is used to short all links in your channel. \n\nMake the bot as an admin in your channel.\n\n 
Command usage: `/batch -100xxxx or @xxx`**"""
